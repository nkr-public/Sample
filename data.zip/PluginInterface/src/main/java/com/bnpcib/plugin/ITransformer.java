package com.bnpcib.plugin;


public interface ITransformer<T extends IPlayLoad, V extends IPlayLoad> {
    V transform(T t);
}