package com.bnpcib.plugin;

public interface IPlayLoad {

    public String toJson();

    public String toXml();

    public String toString();

}
