package com.bnpparibas.hmr.maven;

import org.apache.commons.lang3.StringUtils;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;

import java.io.File;

@Mojo(name="testHmrAnnotate", defaultPhase=LifecyclePhase.GENERATE_TEST_SOURCES, requiresDependencyResolution=ResolutionScope.TEST, threadSafe=true)
public class TestHmrAnnotateMojo extends AbstractHmrMojo {

    /**
     * Location of the lombok annotated source files.
     */
    @Parameter(property="hmr.testSourceDirectory", defaultValue="${project.basedir}/src/test", required=true)
    private File sourceDirectory;

    /**
     * Location of the generated source files.
     */
    @Parameter(property="hmr.testOutputDirectory", defaultValue="${project.build.directory}/generated-test-sources/hmr", required=true)
    private File outputDirectory;

    @Override
    protected String getGoalDescription() {
        return "Test hmrAnnotate";
    }

    @Override
    protected File getOutputDirectory() {
        return outputDirectory;
    }

    @Override
    protected File getSourceDirectory() {
        return sourceDirectory;
    }

    @Override
    protected String getSourcePath() {
        return StringUtils.joinWith(File.pathSeparator,
                StringUtils.join(this.project.getCompileSourceRoots(), File.pathSeparatorChar),
                StringUtils.join(this.project.getTestCompileSourceRoots(), File.pathSeparatorChar)
        );
    }

    @Override
    protected void addSourceRoot(final String path) {
        project.addTestCompileSourceRoot(path);
    }
}