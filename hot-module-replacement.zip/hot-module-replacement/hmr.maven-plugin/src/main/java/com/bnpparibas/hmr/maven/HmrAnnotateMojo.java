package com.bnpparibas.hmr.maven;

import org.apache.commons.lang3.StringUtils;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;

import java.io.File;


@Mojo(name="hmrAnnotate", defaultPhase=LifecyclePhase.GENERATE_SOURCES, requiresDependencyResolution=ResolutionScope.COMPILE, threadSafe=true)
public class HmrAnnotateMojo extends AbstractHmrMojo {

    @Parameter(property="hmr.sourceDirectory", defaultValue="${project.basedir}/src/main", required=true)
    private File sourceDirectory;

    @Parameter(property="hmr.outputDirectory", defaultValue="${project.build.directory}/generated-sources/hmr", required=true)
    private File outputDirectory;

    @Override
    protected String getGoalDescription() {
        return "hmrAnnotate";
    }

    @Override
    protected File getOutputDirectory() {
        return outputDirectory;
    }

    @Override
    protected File getSourceDirectory() {
        return sourceDirectory;
    }

    @Override
    protected String getSourcePath() {
        return StringUtils.join(this.project.getCompileSourceRoots(), File.pathSeparatorChar);
    }

    @Override
    protected void addSourceRoot(final String path) {
        project.addCompileSourceRoot(path);
    }
}