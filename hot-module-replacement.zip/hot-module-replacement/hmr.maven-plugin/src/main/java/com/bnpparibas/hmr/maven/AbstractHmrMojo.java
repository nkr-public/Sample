package com.bnpparibas.hmr.maven;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.bnpparibas.hmr.launch.HmrLauncher;
import org.apache.commons.lang3.JavaVersion;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.apache.maven.artifact.Artifact;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.logging.Log;
import org.apache.maven.plugin.descriptor.PluginDescriptor;
import org.apache.maven.plugins.annotations.Component;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;
import org.sonatype.plexus.build.incremental.BuildContext;


public abstract class AbstractHmrMojo extends AbstractMojo {

    @Parameter(property = "hmr.hmrAnnotate.skip", defaultValue = "false", required = true)
    protected boolean skip;

    @Parameter(property = "hmr.encoding", defaultValue = "${project.build.sourceEncoding}", required = true)
    protected String encoding;

    @Parameter(property = "hmr.verbose", defaultValue = "false", required = true)
    protected boolean verbose;

    @Parameter(property = "hmr.addOutputDirectory", defaultValue = "true", required = true)
    protected boolean addOutputDirectory;

    @Parameter
    protected Map<String, String> formatPreferences;

    @Parameter(property = "project", required = true, readonly = true)
    protected MavenProject project;

    @Parameter(property = "plugin.artifacts", required = true, readonly = true)
    private List<Artifact> pluginArtifacts;

    @Parameter(property = "plugin", required = true, readonly = true)
    protected PluginDescriptor pluginDescriptor;

    @Component
    private BuildContext buildContext;

    protected abstract String getGoalDescription();

    protected abstract File getOutputDirectory();

    protected abstract File getSourceDirectory();

    protected abstract String getSourcePath();

    protected abstract void addSourceRoot(String path);

    @Override
    public void execute() throws MojoExecutionException {
        final Log logger = getLog();
        assert null != logger;

        final String goal = getGoalDescription();
        logger.debug("Starting " + goal);
        final File outputDirectory = getOutputDirectory();
        logger.debug("outputDirectory: " + outputDirectory);
        final File sourceDirectory = getSourceDirectory();
        logger.debug("sourceDirectory: " + sourceDirectory);
        final String sourcePath = getSourcePath();
        logger.debug("sourcePath: " + sourcePath);

        if (this.skip) {
            logger.info("Skipping " + goal);
        } else if (sourceDirectory.exists()) {
            // Build a classPath for delombok...
            final StringBuilder classPathBuilder = new StringBuilder();
            for (final Object artifact : project.getArtifacts()) {
                classPathBuilder.append(((Artifact) artifact).getFile()).append(File.pathSeparatorChar);
            }
            for (final Artifact artifact : pluginArtifacts) {
                classPathBuilder.append(artifact.getFile()).append(File.pathSeparatorChar);
            }
            // delombok needs tools.jar (prior to Java 9)...
            if (!SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_9)) {
                final String javaHome = System.getProperty("java.home");
                final File toolsJar = new File(javaHome,
                        ".." + File.separatorChar + "lib" + File.separatorChar + "tools.jar");
                if (toolsJar.exists()) {
                    try {
                        pluginDescriptor.getClassRealm().addURL(toolsJar.toURI().toURL());
                    } catch (final IOException e) {
                        logger.warn("Unable to add tools.jar; " + toolsJar);
                    }
                } else {
                    logger.warn("Unable to detect tools.jar; java.home is " + javaHome);
                }
            }
            final String classPath = classPathBuilder.toString();
            logger.debug("classpath: " + classPath);
            try {
                final HmrLauncher hmr = new HmrLauncher();
                hmr.setVerbose(this.verbose);
                hmr.setClasspath(classPath);

                if (StringUtils.isNotBlank(this.encoding)) {
                    try {
                        hmr.setCharset(this.encoding);
                    } catch (final UnsupportedCharsetException e) {
                        logger.error("The encoding parameter is invalid; Please check!", e);
                        throw new MojoExecutionException("Unknown charset: " + this.encoding, e);
                    }
                } else {
                    logger.warn("No encoding specified; using default: " + Charset.defaultCharset());
                }

                if (null != formatPreferences && !formatPreferences.isEmpty()) {
                    try {
                        final List<String> formatOptions = new ArrayList<String>(formatPreferences.size());
                        for (final Map.Entry<String, String> entry : formatPreferences.entrySet()) {
                            final String key = entry.getKey();
                            // "pretty" is an exception -- it has no value...
                            formatOptions.add("pretty".equalsIgnoreCase(key) ? key : (key + ':' + entry.getValue()));
                        }
                        hmr.setFormatPreferences(hmr.formatOptionsToMap(formatOptions));
                    } catch (final Exception e) {
                        logger.error("The formatPreferences parameter is invalid; Please check!", e);
                        throw new MojoExecutionException("Invalid formatPreferences: " + this.formatPreferences, e);
                    }
                }

                try {
                    hmr.setOutput(outputDirectory);
                    hmr.setSourcePath(getSourcePath());
                    hmr.addDirectory(sourceDirectory);
                    if (buildContext.hasDelta(sourceDirectory)) {
                        hmr.overrideAnnotation();
                        logger.info(goal + " complete.");

                        if (this.addOutputDirectory) {
                            // adding generated sources to Maven project
                            addSourceRoot(outputDirectory.getCanonicalPath());
                            // Notify build context about a file created, updated or deleted...
                            buildContext.refresh(outputDirectory);
                        }
                    } else {
                        logger.info(goal + " skipped; No deltas detected.");
                    }
                } catch (final IOException e) {
                    logger.error("Unable to hmr!", e);
                    throw new MojoExecutionException("I/O problem during hmr", e);
                }
            } catch (Exception e) {
                throw new MojoExecutionException("Unable to HmrAnnotate", e);
            }
        } else {
            logger.warn("Skipping " + goal + "; no source to process.");
        }
    }
}