package com.bnpparibas.hmr.launch;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class HmrLauncher {
    private final Object hmrInstance;

    private final Method addDirectory;
    private final Method hmr;
    private final Method formatOptionsToMap;
    private final Method setVerbose;
    private final Method setCharset;
    private final Method setClasspath;
    private final Method setFormatPreferences;
    private final Method setOutput;
    private final Method setSourcePath;

    public HmrLauncher() throws ClassNotFoundException, IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException {
        final ClassLoader shadowClassLoader = HmrMain.getShadowClassLoader();
        final Class<?> hmrClass = shadowClassLoader.loadClass("com.bnpparibas.hmr.launch.Hmr");
        this.hmrInstance = hmrClass.getDeclaredConstructor().newInstance();
        this.addDirectory = hmrClass.getMethod("addDirectory", File.class);
        this.hmr = hmrClass.getMethod("overrideAnnotation");
        this.formatOptionsToMap = hmrClass.getMethod("formatOptionsToMap", List.class);
        this.setVerbose = hmrClass.getMethod("setVerbose", boolean.class);
        this.setCharset = hmrClass.getMethod("setCharset", String.class);
        this.setClasspath = hmrClass.getMethod("setClasspath", String.class);
        this.setFormatPreferences = hmrClass.getMethod("setFormatPreferences", Map.class);
        this.setOutput = hmrClass.getMethod("setOutput", File.class);
        this.setSourcePath = hmrClass.getMethod("setSourcePath", String.class);
    }

    public void addDirectory(final File base) throws IllegalAccessException, IOException, InvocationTargetException {
        addDirectory.invoke(hmrInstance, base);
    }

    public boolean overrideAnnotation() throws IllegalAccessException, IOException, InvocationTargetException {
        return Boolean.parseBoolean(hmr.invoke(hmrInstance).toString());
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> formatOptionsToMap(final List<String> formatOptions) throws Exception {
        return (Map<String, String>) formatOptionsToMap.invoke(null, formatOptions);
    }

    public void setVerbose(final boolean verbose) throws IllegalAccessException, InvocationTargetException {
        setVerbose.invoke(hmrInstance, verbose);
    }

    public void setCharset(final String charset) throws IllegalAccessException, InvocationTargetException {
        setCharset.invoke(hmrInstance, charset);
    }

    public void setClasspath(final String classpath) throws IllegalAccessException, InvocationTargetException {
        setClasspath.invoke(hmrInstance, classpath);
    }

    public void setFormatPreferences(final Map<String, String> prefs) throws IllegalAccessException, InvocationTargetException {
        setFormatPreferences.invoke(hmrInstance, prefs);
    }

    public void setOutput(final File dir) throws IllegalAccessException, InvocationTargetException {
        setOutput.invoke(hmrInstance, dir);
    }

    public void setSourcePath(final String sourcePath) throws IllegalAccessException, InvocationTargetException {
        setSourcePath.invoke(hmrInstance, sourcePath);
    }
}
