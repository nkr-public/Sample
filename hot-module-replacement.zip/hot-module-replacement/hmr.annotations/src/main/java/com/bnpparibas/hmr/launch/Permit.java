package com.bnpparibas.hmr.launch;

import java.lang.reflect.Field;

public class Permit {
    public static Field getField(Class<?> delegateClass, String delegate) {
        return null;
    }
}
