package com.bnpparibas.hmr.launch;

import com.sun.tools.javac.tree.JCTree;

public class JavacAugments {
    private JavacAugments() {
        // Prevent instantiation
    }

    public static final FieldAugment<JCTree, Boolean> JCTree_handled = FieldAugment.augment(JCTree.class, boolean.class, "hmr$handled");
    public static final FieldAugment<JCTree, JCTree> JCTree_generatedNode = FieldAugment.circularSafeAugment(JCTree.class, JCTree.class, "hmr$generatedNode");
    public static final FieldAugment<JCTree.JCImport, Boolean> JCImport_deletable = FieldAugment.circularSafeAugment(JCTree.JCImport.class, Boolean.class, "hmr$deletable");
}
