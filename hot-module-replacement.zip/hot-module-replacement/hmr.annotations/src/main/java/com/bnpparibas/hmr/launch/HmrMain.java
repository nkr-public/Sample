package com.bnpparibas.hmr.launch;

import java.util.Arrays;

public class HmrMain {
    private static ShadowClassLoader classLoader;

    HmrMain() {
    }

    static synchronized ClassLoader getShadowClassLoader() {
        if (classLoader == null) {
            classLoader = new ShadowClassLoader(HmrMain.class.getClassLoader(), "hmr", Arrays.asList(), Arrays.asList("hmr.patcher.Symbols"));
        }

        return classLoader;
    }

    static synchronized void prependClassLoader(ClassLoader loader) {
        getShadowClassLoader();
        classLoader.prependParent(loader);
    }

}
