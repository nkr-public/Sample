package com.bnpparibas.hmr;


import com.bnpparibas.hmr.annotations.LambdaAction;
import com.bnpparibas.hmr.annotations.LambdaFunction;
import lombok.Data;

@LambdaFunction(name = "Lambda1")
@Data
public class FunctionLambda {
    private int v=0;
    @LambdaAction(name = "printFunction")
    public void print() {
        System.out.println();
    }
}