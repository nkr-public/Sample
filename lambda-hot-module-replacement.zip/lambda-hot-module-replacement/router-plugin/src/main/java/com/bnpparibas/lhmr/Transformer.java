package com.bnpparibas.lhmr;

import com.bnpparibas.lhmr.model.PlayLoad;

public interface Transformer<IN extends PlayLoad, OUT extends PlayLoad> {
    OUT transform(IN playLoad);
}
