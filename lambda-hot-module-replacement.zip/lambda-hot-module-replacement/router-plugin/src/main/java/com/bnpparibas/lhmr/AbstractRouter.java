package com.bnpparibas.lhmr;

import java.io.File;

public abstract class AbstractRouter {

    public void initConfig(File configFile) {

    }
}