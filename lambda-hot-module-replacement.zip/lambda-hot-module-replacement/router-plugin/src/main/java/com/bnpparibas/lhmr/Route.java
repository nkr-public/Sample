package com.bnpparibas.lhmr;

import com.bnpparibas.lhmr.model.PlayLoad;

//public class Route<IN extends PlayLoad, OUT extends PlayLoad> {
public class Route {
    private Session session;
    private String action;

    public Route(Session session, String action) {
        this.session = session;
        this.action = action;
    }

    public Session getOutSession() {
        return this.session;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
