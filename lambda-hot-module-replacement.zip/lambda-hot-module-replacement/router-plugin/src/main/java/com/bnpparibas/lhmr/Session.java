package com.bnpparibas.lhmr;

import java.util.HashSet;
import java.util.Set;

public class Session {
    private Set<Route> routes = new HashSet<>();

    public Set<Route> getRoutes() {
        return routes;
    }

    public void addRoute(Route route) {
        this.routes.add(route);
    }

    public void removeRoute(Route route) {
        this.routes.remove(route);
    }
}
