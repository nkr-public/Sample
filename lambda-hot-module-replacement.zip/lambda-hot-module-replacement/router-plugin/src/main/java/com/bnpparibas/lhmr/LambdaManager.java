package com.bnpparibas.lhmr;

public class LambdaManager {
}
