package com.bnpparibas.lhmr;

import java.lang.reflect.Method;
import java.util.Map;

public class LambdaManager {
    Map<Method,Object>
}
