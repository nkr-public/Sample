package com.bnpparibas.lhmr;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;


public class RouterContext implements Serializable {
    private String name;
    private String version;
    private Set<Session> sessions = new HashSet<>();
    private Set<Route> routers = new HashSet<>();
}
