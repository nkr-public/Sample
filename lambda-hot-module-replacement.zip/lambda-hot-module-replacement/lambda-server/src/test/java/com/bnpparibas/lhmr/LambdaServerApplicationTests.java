package com.bnpparibas.lhmr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LambdaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
