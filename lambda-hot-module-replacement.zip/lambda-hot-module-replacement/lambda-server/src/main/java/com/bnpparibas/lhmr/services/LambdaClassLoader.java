package com.bnpparibas.lhmr.services;

import com.bnpparibas.lhmr.IDynamicLambda;
import com.bnpparibas.lhmr.ITransformerLambda;
import com.bnpparibas.lhmr.annotations.LambdaFunction;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

public class LambdaClassLoader {
    private final URLClassLoader classLoader;
    private String pluginPath;

    public LambdaClassLoader(String pluginPath) throws MalformedURLException {
        this.pluginPath = pluginPath;
        URL[] urls = {new URL("jar:file:" + this.pluginPath + "!/")};
        this.classLoader = URLClassLoader.newInstance(urls);
    }

    public LambdaClassLoader(File pluginFile) throws MalformedURLException {
        this(pluginFile.getAbsolutePath());
    }

    public List<IDynamicLambda> loadPlugin() throws ClassNotFoundException, InstantiationException, IllegalAccessException, IOException {
        JarFile plugin = new JarFile(pluginPath);
        Enumeration<JarEntry> entries = plugin.entries();
        List<String> clazzNames = new ArrayList<>();
        while (entries.hasMoreElements()) {
            JarEntry jarEntry = entries.nextElement();
            if (jarEntry.isDirectory() || !jarEntry.getName().endsWith(".class")) {
                continue;
            }
            String className = jarEntry.getName()
                    .substring(0, jarEntry.getName().length() - 6)
                    .replace('/', '.');
            clazzNames.add(className);
        }
        List<IDynamicLambda> dynamicLambdas = new ArrayList<>();
        for (String clazzName : clazzNames) {
            dynamicLambdas.add(loadAndFilter(clazzName));
        }
        return dynamicLambdas.stream().filter(Objects::nonNull).collect(Collectors.toList());
    }

    private IDynamicLambda loadAndFilter(String clazzName) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class<?> clazz = classLoader.loadClass(clazzName);
        if (Arrays.stream(clazz.getAnnotations())
                .filter(annotation -> annotation instanceof LambdaFunction)
                .count() > 0) {
            ITransformerLambda inst = (ITransformerLambda) clazz.newInstance();
            System.out.println(inst.printVersion());
            System.out.println(inst.printVersionFinal());            return inst;
        }
        return null;
    }


    public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        String pathToJar = "/home/aelfayafi/IdeaProjects/pluginsProject/lambda-hot-module-replacement/lambda-plugin/target/lambda-plugin-1.0-SNAPSHOT.jar";
        List<IDynamicLambda> result = new LambdaClassLoader(pathToJar).loadPlugin();
        System.out.println(result);


    }
}
