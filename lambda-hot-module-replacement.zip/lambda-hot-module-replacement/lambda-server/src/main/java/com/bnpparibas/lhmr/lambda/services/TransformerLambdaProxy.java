package com.bnpparibas.lhmr.lambda.services;

import com.bnpparibas.lhmr.lambda.ITransformerLambda;
import com.bnpparibas.lhmr.lambda.Reloadable;
import com.bnpparibas.lhmr.model.MsgOne;
import com.bnpparibas.lhmr.model.MsgTwo;

public class TransformerLambdaProxy implements ITransformerLambda , Reloadable<ITransformerLambda> {

    @Override
    public MsgTwo msgOne2Two(MsgOne msg) {
        return null;
    }

    @Override
    public MsgOne msgTwo2One(MsgTwo msg) {
        return null;
    }

    @Override
    public void update(Class<ITransformerLambda> reloadedClass) {

    }
}
