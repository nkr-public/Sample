package com.bnpparibas.lhmr.services;

import com.bnpparibas.lhmr.IDynamicLambda;
import com.bnpparibas.lhmr.Reloadable;
import com.bnpparibas.lhmr.config.ApplicationProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Executor;

import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY;

@Service
@Scope(value = BeanDefinition.SCOPE_SINGLETON)
public class PluginWatchService {
    private static final Logger log = LoggerFactory.getLogger(PluginWatchService.class);
    private final ApplicationProperties applicationProperties;
    DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ssss");
    private int nbTries = 0;
    private WatchService watchService;
    private final Executor taskExecutor;
    private final List<Reloadable> dynamicLambdas = new ArrayList<>();
    private final Map<String, IDynamicLambda> reloadableInstances = new HashMap<>();

    public PluginWatchService(ApplicationProperties applicationProperties, @Qualifier("taskExecutor") Executor taskExecutor) {
        this.applicationProperties = applicationProperties;
        this.taskExecutor = taskExecutor;
    }

    public void addDynamicLambda(Reloadable dynamicLambda) {
        this.dynamicLambdas.add(dynamicLambda);
    }

    @PostConstruct
    void addWatcher() {
        iniWorkspace();
        taskExecutor.execute(() -> {
            try {
                this.watchService = FileSystems.getDefault().newWatchService();
                this.registerDirectory(watchService, applicationProperties.getRepository().getConfig());
                this.registerDirectory(watchService, applicationProperties.getRepository().getPlugin().getLambda());
                this.registerDirectory(watchService, applicationProperties.getRepository().getPlugin().getRouter());
                processWatchEvents();
            } catch (IOException e) {
                log.error("Unable to initialize workspace :", e);
                nbTries++;
                if (nbTries < 3) {
                    addWatcher();
                }
            }
        });
    }

    private void processWatchEvents() {
        WatchKey watchKey;
        while (true) {

            try {
                while ((watchKey = watchService.take()) != null) {
                    for (WatchEvent<?> event : watchKey.pollEvents()) {
                        System.out.println(
                                "Event kind:" + event.kind()
                                        + ". File affected: " + event.context() + ".");
                    }
                    loadJars(applicationProperties.getRepository().getPlugin().getLambda());
                    this.dynamicLambdas.forEach(iDynamicLambda -> iDynamicLambda.reloadInstance(reloadableInstances));
                    watchKey.reset();
                }
            } catch (InterruptedException x) {
                return;
            }
        }
    }

    private void loadJars(String dirPath) {
        File dir = new File(dirPath);
        if (dir.isDirectory()) {
            Arrays.stream(Objects.requireNonNull(dir.listFiles()))
                    .filter(file -> !file.isDirectory())
                    .forEach(file ->
                            {
                                try {
                                    LambdaClassLoader cl = new LambdaClassLoader(file);
                                    cl.loadPlugin().forEach(iDynamicLambda -> {
                                        this.reloadableInstances.put(iDynamicLambda.getClass().getCanonicalName(), iDynamicLambda);
                                    });
                                    String archiveName = dateFormat.format(new Date()) + "_" + file.getName();
                                    file.renameTo(new File(applicationProperties.getArchive().getPlugin().getLambda() + File.separator + archiveName));
                                } catch (MalformedURLException e) {
                                    // TODO
                                    throw new RuntimeException(e);
                                } catch (IOException e) {
                                    throw new RuntimeException(e);
                                } catch (ClassNotFoundException e) {
                                    throw new RuntimeException(e);
                                } catch (InstantiationException e) {
                                    throw new RuntimeException(e);
                                } catch (IllegalAccessException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                    );
        }
    }

    private void registerDirectory(WatchService watcher, String dirPath) throws IOException {
        Paths.get(dirPath).register(watcher, ENTRY_CREATE, ENTRY_MODIFY);
    }

    private void iniWorkspace() {
        ApplicationProperties.Directory[] data = {applicationProperties.getArchive(), applicationProperties.getErrors(), applicationProperties.getRepository()};
        Arrays.stream(data).forEach(directory -> {
            mkdirAndParents(new File(directory.getConfig()));
            mkdirAndParents(new File(directory.getPlugin().getLambda()));
            mkdirAndParents(new File(directory.getPlugin().getRouter()));
        });
    }

    private boolean mkdirAndParents(File dir) {
        File parent = dir.getParentFile();
        if (!parent.exists()) {
            mkdirAndParents(parent);
        }
        if (!dir.exists()) {
            return dir.mkdir();
        }
        return true;
    }
}
