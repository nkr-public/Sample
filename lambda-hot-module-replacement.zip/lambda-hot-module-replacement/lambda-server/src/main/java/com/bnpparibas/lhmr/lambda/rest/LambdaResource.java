package com.bnpparibas.lhmr.lambda.rest;

import com.bnpparibas.lhmr.lambda.config.ApplicationProperties;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;

@RestController
@RequestMapping("api/lambda")
public class LambdaResource {
    private final ApplicationProperties applicationProperties;

    public LambdaResource(ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
    }

    @PostConstruct
    public void show(){
        System.out.println(this.applicationProperties.getWorkspace());
    }
}
