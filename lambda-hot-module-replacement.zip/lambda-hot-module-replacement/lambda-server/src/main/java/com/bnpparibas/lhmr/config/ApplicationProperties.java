package com.bnpparibas.lhmr.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app", ignoreUnknownFields = false)
public class ApplicationProperties {
    private String workspace;

    private Directory repository;
    private Directory archive;
    private Directory errors;

    public String getWorkspace() {
        return workspace;
    }

    public void setWorkspace(String workspace) {
        this.workspace = workspace;
    }

    public Directory getRepository() {
        return repository;
    }

    public void setRepository(Directory repository) {
        this.repository = repository;
    }

    public Directory getArchive() {
        return archive;
    }

    public void setArchive(Directory archive) {
        this.archive = archive;
    }

    public Directory getErrors() {
        return errors;
    }

    public void setErrors(Directory errors) {
        this.errors = errors;
    }

    public static class Directory {
        private String config;
        private PluginDirectory plugin;

        public String getConfig() {
            return config;
        }

        public void setConfig(String config) {
            this.config = config;
        }

        public PluginDirectory getPlugin() {
            return plugin;
        }

        public void setPlugin(PluginDirectory plugin) {
            this.plugin = plugin;
        }

        public static class PluginDirectory {
            private String lambda;
            private String router;

            public String getLambda() {
                return lambda;
            }

            public void setLambda(String lambda) {
                this.lambda = lambda;
            }

            public String getRouter() {
                return router;
            }

            public void setRouter(String router) {
                this.router = router;
            }
        }
    }

}
