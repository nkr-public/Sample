package com.bnpparibas.lhmr.lambda.services;

import com.bnpparibas.lhmr.lambda.config.ApplicationProperties;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.*;

import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;

@Service
@Scope(value = BeanDefinition.SCOPE_SINGLETON)
public class ResourceWatchService {
    private static final Logger log = LoggerFactory.getLogger(ResourceWatchService.class);
    private final ApplicationProperties applicationProperties;
    private int nbTries = 0;
    private WatchService watcher;

    public ResourceWatchService(ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
    }

    @PostConstruct
    void addWatcher() {
        try {
            this.watcher = FileSystems.getDefault().newWatchService();
            this.registerDirectory(watcher);
            processWatchEvents();
        } catch (IOException e) {
            log.error("Unable to initialize workspace :",e);
            nbTries++;
            if (nbTries < 3) {
                addWatcher();
            }
        }
    }

    private void processWatchEvents() {
        WatchKey watchKey;
        while (true) {
            try {
                watchKey = watcher.take();
                System.out.println(watchKey);
            } catch (InterruptedException x) {
                return;
            }
        }
    }

    private void registerDirectory(WatchService watcher) throws IOException {
        Paths.get(applicationProperties.getWorkspace()).register(watcher, ENTRY_CREATE);
    }
}
