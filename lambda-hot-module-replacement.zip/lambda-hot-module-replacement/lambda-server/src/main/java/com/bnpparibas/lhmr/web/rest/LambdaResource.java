package com.bnpparibas.lhmr.web.rest;

import com.bnpparibas.lhmr.services.PluginWatchService;
import com.bnpparibas.lhmr.services.TransformerLambdaProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/lambda")
public class LambdaResource {
    private static final Logger log = LoggerFactory.getLogger(PluginWatchService.class);
    private final TransformerLambdaProxy transformerLambdaProxy;

    public LambdaResource(TransformerLambdaProxy transformerLambdaProxy) {
        this.transformerLambdaProxy = transformerLambdaProxy;
    }

    @GetMapping(value = "/checkVersion", produces = MediaType.APPLICATION_JSON_VALUE)
    public void checkVersion() {
        log.info("######################################################################");
        log.info("# Start LambdaResource checkVersion");
        log.info("######################################################################");
        transformerLambdaProxy.printVersion();
        transformerLambdaProxy.printVersionFinal();
        log.info("######################################################################");
        log.info("# End LambdaResource checkVersion");
        log.info("######################################################################");
    }

}
