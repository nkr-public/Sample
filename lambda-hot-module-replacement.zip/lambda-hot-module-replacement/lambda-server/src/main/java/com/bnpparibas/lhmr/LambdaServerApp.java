package com.bnpparibas.lhmr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LambdaServerApp  {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(LambdaServerApp.class);
        app.run(args);
    }

}
