package com.bnpparibas.lhmr.services;

import com.bnpparibas.lhmr.ITransformerLambda;
import com.bnpparibas.lhmr.Reloadable;
import com.bnpparibas.lhmr.model.MsgOne;
import com.bnpparibas.lhmr.model.MsgTwo;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@Scope(value = BeanDefinition.SCOPE_SINGLETON)
public class TransformerLambdaProxy implements ITransformerLambda, Reloadable<ITransformerLambda> {

    private ITransformerLambda dynamicInstance = null;

    public TransformerLambdaProxy(PluginWatchService pluginWatchService) {
        pluginWatchService.addDynamicLambda(this);
    }

    @Override
    public MsgTwo msgOne2Two(MsgOne msg) {
        return dynamicInstance.msgOne2Two(msg);
    }

    @Override
    public MsgOne msgTwo2One(MsgTwo msg) {
        return dynamicInstance.msgTwo2One(msg);
    }

    @Override
    public String printVersion() {
        return dynamicInstance.printVersion();
    }


    @Override
    public String printVersionFinal() {
        return dynamicInstance.printVersionFinal();
    }

    @Override
    public void reloadInstance(Map<String, Reloadable> lambdaInstances) {
        dynamicInstance = (ITransformerLambda) lambdaInstances.values().stream().findFirst().get();
    }
}
