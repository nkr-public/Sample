package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "sessionsFolder")
public class SessionsFolder 
{
    private List<Folder> folders;

    public List<Folder> getFolder()
    {
        if(folders == null){
            folders = new ArrayList<>();
        }
        return folders;
    }

    public void setFolder(List<Folder> folders)
    {
        this.folders = folders;
    }

}
