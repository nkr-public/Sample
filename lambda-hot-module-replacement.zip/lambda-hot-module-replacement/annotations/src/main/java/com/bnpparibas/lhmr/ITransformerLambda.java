package com.bnpparibas.lhmr;

import com.bnpparibas.lhmr.model.MsgOne;
import com.bnpparibas.lhmr.model.MsgTwo;

public interface ITransformerLambda extends IDynamicLambda {
    MsgTwo msgOne2Two(MsgOne msg);

    MsgOne msgTwo2One(MsgTwo msg);

    String printVersion();

    String printVersionFinal();
}
