package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "settingsRouter")
public class SettingsRouter
{
    private Sessions sessions;
    
    private Routers routers;   
    
    public Sessions getSessions()
    {
        return sessions;
    }

    public void setSessions(Sessions sessions)
    {
        this.sessions = sessions;
    }

    public Routers getRouters()
    {
        return routers;
    }

    public void setRouters(Routers routers)
    {
        this.routers = routers;
    }
}
