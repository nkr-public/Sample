package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "sessionsFix")
public class SessionsFix
{

    private List<Fix> fix;

    public List<Fix> getFix()
    {
        if(fix == null){
            fix= new ArrayList<>();
        }
        return fix;
    }

    public void setFix(List<Fix> fix)
    {
        this.fix = fix;
    }
   
}
