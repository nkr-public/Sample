package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "fix")
public class Fix extends SessionMaster
{
    private String logType;
    
    private String urlFileConfig;
    
    public void setUrlFileConfig(String urlFileConfig)
    {
        this.urlFileConfig = urlFileConfig;
    }

    public String getUrlFileConfig()
    {
        return urlFileConfig;
    }
    
    public void setLogType(String logType)
    {
        this.logType = logType; 
    }
    
    public String getLogType()
    {
        return logType; 
    }
    
    @Override
    public String toString()
    {
        return String.format("Fix session %s with config file %s", name, urlFileConfig);
    }
}
