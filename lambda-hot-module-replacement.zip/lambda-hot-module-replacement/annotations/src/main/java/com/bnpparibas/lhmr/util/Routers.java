package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "routers")
public class Routers
{
    private List<Router> router;

    public List<Router> getRouter()
    {
        if (router == null){
            router = new ArrayList<>();            
        }
        return router;
    }

    public void setRouter(List<Router> rule)
    {
        this.router = rule;
    }    
}
