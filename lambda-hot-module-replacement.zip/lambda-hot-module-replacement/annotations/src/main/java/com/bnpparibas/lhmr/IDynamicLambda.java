package com.bnpparibas.lhmr;

public interface IDynamicLambda {
}
