package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "rules")
public class Rules
{
    private List<Rule> rule;

    public List<Rule> getRule()
    {
        if (rule == null){
            rule = new ArrayList<>();            
        }
        return rule;
    }

    public void setRule(List<Rule> rule)
    {
        this.rule = rule;
    }    
}
