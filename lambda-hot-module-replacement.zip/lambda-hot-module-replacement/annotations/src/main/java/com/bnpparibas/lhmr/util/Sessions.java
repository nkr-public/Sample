package com.bnpparibas.lhmr.util;


import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "sessions")
public class Sessions
{
    private SessionsMq sessionsMq;
    
    private SessionsFix sessionsFix;
    
    private SessionsFolder sessionsFolder;

    public SessionsMq getSessionsMq()
    {
        return sessionsMq;
    }

    public void setSessionsMq(SessionsMq sessionsMq)
    {
        this.sessionsMq = sessionsMq;
    }

    public SessionsFix getSessionsFix()
    {
        return sessionsFix;
    }

    public void setSessionsFix(SessionsFix sessionsFix)
    {
        this.sessionsFix = sessionsFix;
    }

    public SessionsFolder getSessionsFolder()
    {
        return sessionsFolder;
    }

    public void setSessionsFolder(SessionsFolder sessionsFolder)
    {
        this.sessionsFolder = sessionsFolder;
    }
    
}
