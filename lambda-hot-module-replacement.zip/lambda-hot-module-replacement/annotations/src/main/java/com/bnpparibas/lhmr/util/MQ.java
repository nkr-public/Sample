package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "mq")
public class MQ extends SessionMaster
{
    private int transportType;
    
    private String queueManager;
     
    private String hostName;    
  
    private int port;    
 
    private String channel;
       
    private String queueName;
      
    private boolean ignoreException;
    
    public int getTransportType()
    {
        return transportType;
    }

    public void setTransportType(int transportType)
    {
        this.transportType = transportType;
    }

    public String getQueueManager()
    {
        return queueManager;
    }

    public void setQueueManager(String queueManager)
    {
        this.queueManager = queueManager;
    }

    public String getHostName()
    {
        return hostName;
    }

    public void setHostName(String hostName)
    {
        this.hostName = hostName;
    }

    public int getPort()
    {
        return port;
    }

    public void setPort(int port)
    {
        this.port = port;
    }

    public String getChannel()
    {
        return channel;
    }

    public void setChannel(String channel)
    {
        this.channel = channel;
    }

    public String getQueueName()
    {
        return queueName;
    }

    public void setQueueName(String queueName)
    {
        this.queueName = queueName;
    }

    public boolean isIgnoreException()
    {
        return ignoreException;
    }

    public void setIgnoreException(boolean ignoreException)
    {
        this.ignoreException = ignoreException;
    }
    
    @Override
    public String toString()
    {
        return String.format("MQ session %s with hostname : %s, queueManager : %s, port : %d, channel : %s, queueName : %s", name, hostName, queueManager, port, channel, queueName);
    }
    
}
