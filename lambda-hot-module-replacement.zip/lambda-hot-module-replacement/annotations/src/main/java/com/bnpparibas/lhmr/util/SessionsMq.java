package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name = "sessionsMQ")
public class SessionsMq
{
    
    private List<MQ> mq;

    public List<MQ> getMq()
    {
        if(mq == null){
            mq = new ArrayList<>();
        }
        return mq;
    }

    public void setMq(List<MQ> mq)
    {
        this.mq = mq;
    }
}
