package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "rule")
public class Rule
{

    private int out;

    public int getOut()
    {
        return out;
    }

    public void setOut(int out)
    {
        this.out = out;
    }
    
    
}
