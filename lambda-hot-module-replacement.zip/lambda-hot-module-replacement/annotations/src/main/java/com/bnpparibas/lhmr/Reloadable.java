package com.bnpparibas.lhmr;

import java.util.Map;

public interface Reloadable<T extends IDynamicLambda> {
    void reloadInstance(Map<String, Reloadable> lambdaInstances);
}
