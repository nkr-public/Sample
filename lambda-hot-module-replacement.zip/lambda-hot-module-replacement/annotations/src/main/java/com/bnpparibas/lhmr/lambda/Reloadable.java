package com.bnpparibas.lhmr.lambda;

public interface Reloadable<T> {
    void update(Class<T> reloadedClass);
}
