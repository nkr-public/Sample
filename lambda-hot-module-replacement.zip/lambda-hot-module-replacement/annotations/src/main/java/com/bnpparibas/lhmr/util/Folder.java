package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "folder")
public class Folder extends SessionMaster
{
    private String urlFolderOutput;
    
    private String fileNamePatternOutput;
    
    private String fileNameExtensionOutput;
    
    private String urlToScan;
    
    private int scanFolderRepeatInterval;
    
    private boolean oneFilePerMessage;
    
    private int fileNumber;
    
    public String getUrlFolderOutput()
    {
        return urlFolderOutput;
    }

    public void setUrlFolderOutput(String urlFolderOutput)
    {
        this.urlFolderOutput = urlFolderOutput;
    }
    
    public String getFileNamePatternOutput()
    {
        return fileNamePatternOutput;
    }

    public void setFileNamePatternOutput(String fileNamePatternOutput)
    {
        this.fileNamePatternOutput = fileNamePatternOutput;
    }

    public String getFileNameExtensionOutput()
    {
        return fileNameExtensionOutput;
    }

    public void setFileNameExtensionOutput(String fileNameExtensionOutput)
    {
        this.fileNameExtensionOutput = fileNameExtensionOutput;
    }

    public String getFileNameOutput()
    {
        return getUrlFolderOutput() + getFileNamePatternOutput() + (oneFilePerMessage ? "_" + fileNumber++ : "") + "." + getFileNameExtensionOutput();
    }
    
    public String getUrlToScan()
    {
        return urlToScan;
    }

    public void setUrlToScan(String urlToScan)
    {
        this.urlToScan = urlToScan;
    }
    
    public int getScanFolderRepeatInterval()
    {
        return scanFolderRepeatInterval;
    }

    public void setScanFolderRepeatInterval(int scanFolderRepeatInterval)
    {
        this.scanFolderRepeatInterval = scanFolderRepeatInterval;
    }

    public boolean isOneFilePerMessage()
    {
        return oneFilePerMessage;
    }

    public void setOneFilePerMessage(boolean oneFilePerMessage)
    {
        this.oneFilePerMessage = oneFilePerMessage;
    }

    @Override
    public String toString()
    {
        return String.format("Folder session %s for folder %s scanned every %d milliseconds, output %s", name, urlToScan, scanFolderRepeatInterval, urlFolderOutput);
    }

}