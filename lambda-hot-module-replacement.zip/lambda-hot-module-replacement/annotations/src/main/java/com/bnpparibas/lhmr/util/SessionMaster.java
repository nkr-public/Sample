package com.bnpparibas.lhmr.util;

import quickfix.DataDictionary;

import java.util.ArrayList;
import java.util.List;

public abstract class  SessionMaster
{
    private static final String METHOD_SHOULD_BE_IMPLEMENTED_IN_THE_CHILD_CLASS = "Method should be implemented in the child class.";

    protected int id;
    
    protected String name;
    
    protected String formatContentIn;
    
    protected String fixDictionnaryFileName;
    
    protected DataDictionary fixDictionnary;
    
    protected String formatContentOut;
    
    protected List<MQ> mqs;
    
    protected List<Fix> fixs;
    
    protected List<Folder> folders;

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getFormatContentIn()
    {
        return formatContentIn;
    }

    public void setFormatContentIn(String formatContentIn)
    {
        this.formatContentIn = formatContentIn;
    }

    public String getFixDictionnaryFileName()
    {
        return fixDictionnaryFileName;
    }

    public void setFixDictionnaryFileName(String fixDictionnaryFileName)
    {
        this.fixDictionnaryFileName = fixDictionnaryFileName;
    }

    public DataDictionary getFixDictionnary()
    {
        return fixDictionnary;
    }

    public void setFixDictionnary(DataDictionary fixDictionnary)
    {
        this.fixDictionnary = fixDictionnary;
    }

    public String getFormatContentOut()
    {
        return formatContentOut;
    }

    public void setFormatContentOut(String formatContentOut)
    {
        this.formatContentOut = formatContentOut;
    }

    public List<MQ> getMqs()
    {
        if(mqs == null){
            mqs = new ArrayList<>();
        }
        return mqs;
    }

    public void setMqs(List<MQ> mqs)
    {
        this.mqs = mqs;
    }

    public List<Fix> getFixs()
    {
        if(fixs == null){
            fixs = new ArrayList<>();
        }
        return fixs;
    }

    public void setFixs(List<Fix> fixs)
    {
        this.fixs = fixs;
    }

    public List<Folder> getFolders()
    {
        if(folders == null){
            folders = new ArrayList<>();
        }
        return folders;
    }

    public void setFolders(List<Folder> folders)
    {
        this.folders = folders;
    }
}
