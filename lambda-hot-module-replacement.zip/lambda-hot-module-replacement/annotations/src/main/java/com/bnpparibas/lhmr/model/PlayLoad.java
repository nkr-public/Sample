package com.bnpparibas.lhmr.model;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public abstract class PlayLoad {
    private long correlationId;
    private LocalDateTime createDate;
}
