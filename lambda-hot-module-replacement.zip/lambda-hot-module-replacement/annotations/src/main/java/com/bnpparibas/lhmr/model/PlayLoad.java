package com.bnpparibas.lhmr.model;

public interface PlayLoad {
}
