package com.bnpparibas.lhmr.util;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "router")
public class Router
{

    private int in;
    
    private Rules rules;

    public int getIn()
    {
        return in;
    }

    public void setIn(int in)
    {
        this.in = in;
    }

    public Rules getRules()
    {
        return rules;
    }

    public void setRules(Rules rules)
    {
        this.rules = rules;
    }
    
    
}
