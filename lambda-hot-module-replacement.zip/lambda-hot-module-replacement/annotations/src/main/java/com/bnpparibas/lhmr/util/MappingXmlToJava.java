package com.bnpparibas.lhmr.util;

import quickfix.ConfigError;
import quickfix.DataDictionary;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import java.io.FileReader;
import java.io.IOException;


public class MappingXmlToJava
{
    private String fileName;

    public MappingXmlToJava(String fileName)
    {
        this.fileName = fileName;
    }

    public SettingsRouter unmarshall() throws JAXBException, IOException
    {
        JAXBContext context = JAXBContext.newInstance(SettingsRouter.class);
        return (SettingsRouter) context.createUnmarshaller().unmarshal(new FileReader(fileName));
    }

    public SessionMaster getSessionIn(Sessions sessions, Rules rules, int in)
    { 
        if (sessions.getSessionsMq() != null)
            for (MQ mqInput : sessions.getSessionsMq().getMq()) {
                if (in == mqInput.getId()) {
                    return mqInput;
                }
            }

        if (sessions.getSessionsFix() != null)
            for (Fix fixInPut : sessions.getSessionsFix().getFix()) {
                if (in == fixInPut.getId()) {
                    return fixInPut;
                }
            }
        
        if (sessions.getSessionsFolder() != null)
            for (Folder folderInPut : sessions.getSessionsFolder().getFolder()) {
                if (in == folderInPut.getId()) {
                    return folderInPut;
                }
            }
        
        return null;
    }

    public void fillSESOutPut(Sessions sessions, SessionMaster sesin, Rules rules)
    {

        boolean found =false;
        for (Rule ruleInput : rules.getRule()) {
            found =false;
            if (sessions.getSessionsMq() != null) {
                for (MQ mqOutPut : sessions.getSessionsMq().getMq()) {
                    if (ruleInput.getOut() == mqOutPut.getId()) {
                        sesin.getMqs().add(mqOutPut);
                        found= true;
                        break;
                    }
                }
            }
            
            if (found) continue;
            if (sessions.getSessionsFix() != null) {
                for (Fix fixOutPut : sessions.getSessionsFix().getFix()) {
                    if (ruleInput.getOut() == fixOutPut.getId()) {
                        sesin.getFixs().add(fixOutPut);
                        break;
                    }
                }
            }
            
            if (found) continue;
            if (sessions.getSessionsFolder() != null) {
                for (Folder folderOutPut : sessions.getSessionsFolder().getFolder()) {
                    if (ruleInput.getOut() == folderOutPut.getId()) {
                        sesin.getFolders().add(folderOutPut);
                        break;
                    }
                }
            }       
        }
    }
    
    public void allocateRules(Sessions sessions, Rules rules, int in) throws ConfigError
    {        
        SessionMaster sessionIn = getSessionIn(sessions,rules,in);

        if(sessionIn != null){
            if (sessionIn.getFixDictionnaryFileName() != null && sessionIn.getFixDictionnary() == null) {
                sessionIn.setFixDictionnary(getDataDictionaryFromFile(sessionIn.getFixDictionnaryFileName()));
            }
            fillSESOutPut( sessions, sessionIn,rules);
        }
    }

    private static DataDictionary getDataDictionaryFromFile(String path) throws ConfigError
    {
        DataDictionary dd = new DataDictionary(path);
        dd.setCheckFieldsOutOfOrder(false);
        dd.setCheckUnorderedGroupFields(false);
        dd.setCheckFieldsHaveValues(false);
        dd.setCheckUserDefinedFields(false);

        return dd;
    }

}
