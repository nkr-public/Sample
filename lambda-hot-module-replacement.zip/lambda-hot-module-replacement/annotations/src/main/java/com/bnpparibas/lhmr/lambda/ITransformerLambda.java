package com.bnpparibas.lhmr.lambda;

import com.bnpparibas.lhmr.model.MsgOne;
import com.bnpparibas.lhmr.model.MsgTwo;

public interface ITransformerLambda {
     MsgTwo msgOne2Two(MsgOne msg);
     MsgOne msgTwo2One(MsgTwo msg);
}
