package com.bnpparibas.lhmr.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MsgOne implements PlayLoad{
    private String k1;
    private String v1;
    private String k2;
    private String v2;
}
