package com.bnpparibas.lhmr.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
public class MsgOne extends PlayLoad{
    private String k1;
    private String v1;
    private String k2;
    private String v2;
}


