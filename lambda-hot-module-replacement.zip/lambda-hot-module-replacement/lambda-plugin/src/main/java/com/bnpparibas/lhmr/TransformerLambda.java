package com.bnpparibas.lhmr;

import com.bnpparibas.lhmr.annotations.LambdaAction;
import com.bnpparibas.lhmr.annotations.LambdaFunction;
import com.bnpparibas.lhmr.lambda.ITransformerLambda;
import com.bnpparibas.lhmr.model.MsgOne;
import com.bnpparibas.lhmr.model.MsgTwo;

@LambdaFunction(name = "TransformerLambda")
public class TransformerLambda implements ITransformerLambda {
    @LambdaAction(name = "msgOne2Two")
    @Override
    public MsgTwo msgOne2Two(MsgOne msg) {
        return new MsgTwo(msg.getK1(), msg.getV1());
    }


    @LambdaAction(name = "msgOne2Two")
    @Override
    public MsgOne msgTwo2One(MsgTwo msg) {
        return new MsgOne(msg.getKey(), msg.getValue(), msg.getValue(), msg.getKey());
    }


}