package com.bnpparibas.lhmr;

import com.bnpparibas.lhmr.annotations.LambdaAction;
import com.bnpparibas.lhmr.annotations.LambdaFunction;
import com.bnpparibas.lhmr.model.MsgOne;
import com.bnpparibas.lhmr.model.MsgTwo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@LambdaFunction(name = "TransformerLambda")
public class TransformerLambda implements ITransformerLambda {
    private static final Logger log = LoggerFactory.getLogger(TransformerLambda.class);
    private String version = "5";

    private final String versionFinal = "5";

    @LambdaAction(name = "msgOne2Two")
    @Override
    public MsgTwo msgOne2Two(MsgOne msg) {
        return new MsgTwo(msg.getK1(), "Changed");
    }

    @LambdaAction(name = "msgOne2Two")
    @Override
    public MsgOne msgTwo2One(MsgTwo msg) {
        return new MsgOne(msg.getKey(), msg.getValue(), msg.getValue(), msg.getKey());
    }

    @LambdaAction(name = "printVersion")
    @Override
    public String printVersion() {
        log.info("##### End print versionFinal Value #####");
        log.info("Current Version Value : " + version);
        log.info("##### End print versionFinal Value #####");
        return version;
    }

    @LambdaAction(name = "printVersionFinal")
    @Override
    public String printVersionFinal() {
        log.info("##### End print versionFinal Value #####");
        log.info("Current VersionFinal Value : " + versionFinal);
        log.info("##### End print versionFinal Value #####");
        return versionFinal;
    }

}